package com.example.practise.service;

import com.example.practise.dtos.FileDetailsDTO;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

public interface UserService {
    public MultipartFile createTextFile(FileDetailsDTO fileDetailsDTO) throws Exception;
}
