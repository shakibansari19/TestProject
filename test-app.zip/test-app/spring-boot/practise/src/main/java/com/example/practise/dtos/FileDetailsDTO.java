package com.example.practise.dtos;

public class FileDetailsDTO {
    private Integer serialNo;
    private String name;

    private Integer noOfPorts;

    private String assetType;

    public Integer getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(Integer serialNo) {
        this.serialNo = serialNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getNoOfPorts() {
        return noOfPorts;
    }

    public void setNoOfPorts(Integer noOfPorts) {
        this.noOfPorts = noOfPorts;
    }

    public String getAssetType() {
        return assetType;
    }

    public void setAssetType(String assetType) {
        this.assetType = assetType;
    }

    @Override
    public String toString() {
        return "{\"serialNo\":"+this.getSerialNo()+","
                +"\"name\":\""+this.getName()+"\""
                +"\"assetType\":\""+this.getAssetType()+"\""
                +"\"noOfPorts\":"+this.getNoOfPorts()+"}";
    }
}
