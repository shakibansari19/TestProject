package com.example.practise.common;

public class CommonUtils {
    public void createTextFile() {

    }
}
