package com.example.practise.serviceimpl;

import com.example.practise.dtos.FileDetailsDTO;
import com.example.practise.service.UserService;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
@Service
public class UserServiceImpl implements UserService {

    @Override
    public MultipartFile createTextFile(FileDetailsDTO fileDetailsDTO) throws Exception {

            if(
                    fileDetailsDTO.getName() != null && !fileDetailsDTO.getName().isEmpty() &&
                    fileDetailsDTO.getSerialNo() != null
            ) {
                String data = fileDetailsDTO.toString();
                System.out.println("data is:::::::::::");
                System.out.println(data);
                try {
                    FileOutputStream outputStream = new FileOutputStream(fileDetailsDTO.getName()+".txt");
                    byte[] strToBytes = data.getBytes();
                    outputStream.write(strToBytes);
                    outputStream.close();
                    String contentType = "text/plain";
                    return new MockMultipartFile(fileDetailsDTO.getName()+".txt", fileDetailsDTO.getName()+".txt", contentType, strToBytes);
                } catch (IOException io) {
                    throw new Exception("Some issue while writing to file.");
                }
            } else {
                throw new Exception("Bad input parameter");
            }

    }
}
