export const AppConstant = {
    basePath: "http://localhost:8080/api"
}