import axios from "axios";
import { AppConstant } from "../app.constants";

export default class UserSharedService {
  baseURL;
  constructor() {
    this.baseURL = AppConstant.basePath + "/user";
  }

  getTest() {
    console.log(this.baseURL+"/test")
    axios.get(this.baseURL+"/test").then((response) => {
      console.log(response.data);
    });
  }
}
