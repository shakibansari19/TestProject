import logo from "./logo.svg";
import "./App.css";
import User from "./components/User/User";

function App() {
  return (
    <div className="App">
      <User />
    </div>
  );
}

export default App;
