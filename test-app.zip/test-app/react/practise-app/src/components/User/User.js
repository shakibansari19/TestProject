import React, { useEffect, useState } from "react";
import UserSharedService from "../../shared/services/user-shared.service";

const User = () => {
  const [userSharedService] = useState(() => new UserSharedService());
  useEffect(() => {
    userSharedService.getTest();
  }, []);

  return <div>test</div>;
};

export default User;
